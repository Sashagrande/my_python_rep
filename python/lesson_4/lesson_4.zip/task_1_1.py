import cProfile

"""Сформировать из введенного числа обратное по порядку входящих в него цифр и вывести на экран.
Например, если введено число 3486, надо вывести 6843."""


def func_1(num):
    if num < 10:
        return f'{num}'
    return f'{num % 10}{func_1(num // 10)}'


# task_1_1.func_1(9**99)
# 1000 loops, best of 5: 75.4 usec per loop

# task_1_1.func_1(9**999)
# 1000 loops, best of 5: 2.75 msec per loop

# task_1_1.func_1(9**9999)
# RecursionError: maximum recursion depth exceeded in comparison


# cProfile.run('func_1(9**99)')
# 95/1    0.000    0.000    0.000    0.000 task_1_1.py:7(func_1)

# cProfile.run('func_1(9**999)')
# 954/1    0.005    0.000    0.005    0.005 task_1_1.py:7(func_1)

# cProfile.run('func_1(9**9999)')
# RecursionError: maximum recursion depth exceeded in comparison

def func_2(num):
    print(num)
    res = ''
    for i in range(0, len(str(num))):
        res += str(num % 10)
        num //= 10
    return res


# task_1_1.func_2(9**99)
# 1000 loops, best of 5: 186 usec per loop

# task_1_1.func_2(99**999)
# 1000 loops, best of 5: 3.32 msec per loop

# task_1_1.func_2(9**9999)
# 10 loops, best of 5: 222 msec per loop (10 попыток потому что 1000 я всё таки не дождался)


# cProfile.run('func_2(9**99)')
# 1    0.000    0.000    0.000    0.000 task_1_1.py:33(func_2)

# cProfile.run('func_2(9**999)')
# 1    0.004    0.004    0.004    0.004 task_1_1.py:33(func_2)

# cProfile.run('func_2(9**9999)')
# 1    0.230    0.230    0.252    0.252 task_1_1.py:33(func_2)

def func_3(num):
    return str(num)[::-1]


# task_1_1.func_3(9**99)
# 1000 loops, best of 5: 2.9 usec per loop

# task_1_1.func_3(9**999)
# 1000 loops, best of 5: 97.8 usec per loop

# task_1_1.func_3(9**9999)
# 1000 loops, best of 5: 8.28 msec per loop


# cProfile.run('func_3(9**99)')
# 1    0.000    0.000    0.000    0.000 task_1_1.py:61(func_3)

# cProfile.run('func_3(9**999)')
# 1    0.000    0.000    0.000    0.000 task_1_1.py:61(func_3)

# cProfile.run('func_3(9**9999)')
# 1    0.009    0.009    0.009    0.009 task_1_1.py:61(func_3)


"""
Вывод - вариант решения задачи с инверсией строки с помощью среза самый оптимальный по скорости выполнения. 
Он не вызывает рекурсию, а так же не производит никаких вычислений
"""
