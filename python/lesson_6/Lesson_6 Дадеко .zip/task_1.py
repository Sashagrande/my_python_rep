import sys

"""
В одномерном массиве целых чисел определить два наименьших элемента.
Они могут быть как равны между собой (оба минимальны), так и различаться.
"""

from random import randint

#  Первый способ
array = [randint(1, 30) for i in range(1, 30)]
# print(array)
minimum = array[0]
result = []
for i in array:
    if i < minimum:
        minimum = i
array.pop(array.index(minimum))
result.append(minimum)
minimum = array[0]
for i in array:
    if i < minimum:
        minimum = i
array.pop(array.index(minimum))
result.append(minimum)
# print(result)
print(sys.getsizeof(array) + sys.getsizeof(minimum) + sys.getsizeof(result), '- Количество занимаемой памяти ')
# 226 - Количество занимаемой памяти


#  Второй способ
array1 = [randint(1, 30) for i in range(1, 30)]
# print(array1)
# print(array1.pop(array1.index(min(array1))), array1.pop(array1.index(min(array1))))
# print(array1)
print(sys.getsizeof(array1.pop(array1.index(min(array1)))) + sys.getsizeof(array1), '- Количество занимаемой памяти')
# 182 - Количество занимаемой памяти


#  Третий способ
array2 = [randint(1, 30) for i in range(1, 30)]
# print(array2)
array2.sort()
# print(array1[:2])
# print(sys.getsizeof(array2.sort()) + sys.getsizeof(array2), '- Количество занимаемой памяти')
# 176 - Количество занимаемой памяти
#
#
# 3.8.5 (tags/v3.8.5:580fbb0, Jul 20 2020, 15:43:08) [MSC v.1926 32 bit (Intel)] win32


# 226 - Количество занимаемой памяти - первый способ (определяем первый минимальный элемент, добавляем его в новый
# список, затем удаляем его, делаем то же самое второй раз / Используется 3 объекта, один из которых перезатирается)


# 182 - Количество занимаемой памяти - второй способ (методом .pop извлекаем минимальный элемент с помощью min(),
# проделываем это еще раз / используется 2 объекта - массив и min(), min() перезатирается)


# 176 - Количество занимаемой памяти - третий способ (Сортируем массив и печатаем первые два элемента
# / используется один объект)

"""
Вывод, третий способ самый оптимальный, так как используется всего один объект - массив, сортируется, и выдает первые
два элемента, поэтому используется наименьшее количество памяти
"""