"""
4. Определить, какое число в массиве встречается чаще всего.
"""


from random import randint

array = [randint(0, 10) for i in range(1, 30)]
print(array)
result = 0
for i in array:
    count = array.count(i)
    if count > result:
        result = count
        a = i
print(f'{result} раз встречается цифра {a}')

