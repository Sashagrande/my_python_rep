"""
3. В массиве случайных целых чисел поменять местами минимальный и максимальный элементы.
"""


from random import randint

array = [randint(-30, 30) for i in range(1, 30)]
print(array)
minimum = 0
maximum = 0
for i in enumerate(array):
    if i[1] < minimum:
        minimum = i[1]
        index_min = i[0]
    if i[1] > maximum:
        maximum = i[1]
        index_max = i[0]
array[index_min], array[index_max] = array[index_max], array[index_min]
print(minimum, maximum, index_min, index_max)
print(array)
