"""
8. Матрица 5x4 заполняется вводом с клавиатуры, кроме последних элементов строк. Программа должна вычислять
сумму введенных элементов каждой строки и записывать ее в последнюю ячейку строки. В конце следует
вывести полученную матрицу.
"""

from random import randint
result = []
for _ in range(1, 5):
    a = []
    for i in range(1, 5):
        x = randint(-15, 15)
        a.append(x)
    a.append(sum(a))
    result.append(a)
print(result)


for i in result:
    for j in i:
        print(f'{j:<8}', end='')
    print()