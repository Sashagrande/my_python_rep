"""
6. В одномерном массиве найти сумму элементов, находящихся между минимальным и максимальным элементами.
 Сами минимальный и максимальный элементы в сумму не включать.
"""

from random import randint

array = [randint(-30, 30) for i in range(1, 30)]
print(array)
minimum = 0
maximum = 0
result = 0
for i in enumerate(array):
    if i[1] < minimum:
        minimum = i[1]
        index_min = i[0]
    if i[1] > maximum:
        maximum = i[1]
        index_max = i[0]
if array.index(minimum) < array.index(maximum):
    for i in range(array.index(minimum)+1, array.index(maximum)):
        result += array[i]
else:
    for i in range(array.index(maximum)+1, array.index(minimum)):
        result += array[i]


print(index_max,maximum, index_min, minimum)
print(result)