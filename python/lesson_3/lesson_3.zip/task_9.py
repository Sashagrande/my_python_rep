"""
Найти максимальный элемент среди минимальных элементов столбцов матрицы.
Примечание: попытайтесь решить задания без использования функций max, min, sum, sorted и их аналогов,
в том числе написанных самостоятельно.
"""

from random import randint

x = int(input('Введите размер квадратной матрицы: '))
array = []
for _ in range(0, x-1):
    a = []
    for i in range(0, x-1):
        a.append(randint(-50, 50))
    array.append(a)

for i in array:
    for j in i:
        print(f'{j:<8}', end='')
    print()

res_array = []

print('♥' * 25)

for i in range(0, x-1):
    minim = 0
    j = 0
    while j < x - 1:
        if array[j][i] < minim:
            minim = array[j][i]
        j += 1
    print(f'{minim:<8}', end='')
    res_array.append(minim)
print()

minim = res_array[0]
for i in res_array:
    if i > minim:
        minim = i
print('Ответ ', minim)
