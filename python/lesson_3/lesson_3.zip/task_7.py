"""
7. В одномерном массиве целых чисел определить два наименьших элемента.
Они могут быть как равны между собой (оба минимальны), так и различаться.
"""

from random import randint

array = [randint(1, 30) for i in range(1, 30)]
print(array)
minimum = array[0]
result = []
for i in array:
    if i < minimum:
        minimum = i
array.pop(array.index(minimum))
result.append(minimum)
minimum = array[0]
for i in array:
    if i < minimum:
        minimum = i
array.pop(array.index(minimum))
result.append(minimum)
print(result)
