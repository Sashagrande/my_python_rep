"""
5. В массиве найти максимальный отрицательный элемент. Вывести на экран его значение и позицию в массиве.
"""


from random import randint

array = [randint(-30, 30) for i in range(1, 30)]
print(array)
maximum = -99
index_min = 0
for i in enumerate(array):
    if i[1] < 0:

        if i[1] > maximum:
            maximum = i[1]
            index_min = i[0]
print(f'{index_min} элемент среди отрицательных самый большой {maximum}')